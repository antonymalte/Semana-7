/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taller7;

import javax.swing.JOptionPane;

/**
 *
 * @author Esteban
 */
public class Descuentos extends Carros{
    
    private int sp;
    private double d1;
    private double d2;
    private double d3;
    private double d4;
 
    
    public Descuentos(int sp, double d1, double d2, double d3,double d4, String marca, String linea, String modelo, double liquidacion, double precio) {
        super(marca, linea, modelo, liquidacion, precio);
        this.sp = sp;
        this.d1 = d1;
        this.d2 = d2;
        this.d3 = d3;
        this.d4 = d4;
       
    }

    Descuentos() {

    }

    public int getSp() {
        return sp;
    }

    public void setSp(int sp) {
        this.sp = sp;
    }

    public double getD1() {
        return d1;
    }

    public void setD1(double d1) {
        this.d1 = d1;
    }

    public double getD2() {
        return d2;
    }

    public void setD2(double d2) {
        this.d2 = d2;
    }

    public double getD3() {
        return d3;
    }

    public void setD3(double d3) {
        this.d3 = d3;
    }

    public double getD4() {
        return d4;
    }

    public void setD4(double d4) {
        this.d4 = d4;
    }

    public double calcular(int iden, double precio){
       double b1=0, b2=0;
        switch(iden){
            case 1:setPrecio(calcularDescuento1(precio));
            break;
            case 2:setPrecio(calcularDescuento2(precio));
            break;
            case 3:setPrecio(calcularDescuento3(precio));
            break;
            case 4:setPrecio(calcularDescuento4(precio, b1, b2));
        }
        return getPrecio();
    }
    
    public double calcularDescuento1(double precio){
        setD1(precio*0.05);
        precio=precio-getD1();
        return precio;
    }
    public double calcularDescuento2(double precio){
        setD2(precio*0.1);
        precio=precio-getD2();
        return precio;
    }
    public double calcularDescuento3(double precio){
        setD3(precio*0.15);
        precio=precio-getD3();
        return precio;
    }
    
    public double calcularDescuento4(double precio, double b1, double b2){
        setD4(calcularDescuento1(precio)*0.1);
        b1=calcularDescuento1(precio)-getD4();
        setD2((precio-getD1())*0.1);
        setD3(((precio-getD1())-getD2())*0.15);
        b2=b1*0.15;
        
        precio=b1-b2;
        
        return precio;
    }
    

}
