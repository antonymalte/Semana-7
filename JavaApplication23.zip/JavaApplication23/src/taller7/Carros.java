/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taller7;

/**
 *
 * @author Esteban
 */
public class Carros {
    String marca;
    String linea;
    String modelo;
    double liquidacion;
    double precio;

    public Carros(String marca, String linea, String modelo, double liquidacion, double precio) {
        this.marca = marca;
        this.linea = linea;
        this.modelo = modelo;
        this.liquidacion = liquidacion;
        this.precio = precio;
    }

    Carros() {
    }
    
    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getLinea() {
        return linea;
    }

    public void setLinea(String linea) {
        this.linea = linea;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public double getLiquidacion() {
        return liquidacion;
    }

    public void setLiquidacion(double liquidacion) {
        this.liquidacion = liquidacion;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
    
    public double precioCarro(String marca, String modelo, String linea){
        if (marca.equalsIgnoreCase("Ford") || modelo.equalsIgnoreCase("Mustang") || linea.equalsIgnoreCase("2013")) {
            precio = 63000000;
            setMarca("Ford"); setLinea("Mustang"); setModelo("2013"); 
        }
        if (marca.equalsIgnoreCase("Chevrolet") || modelo.equalsIgnoreCase("Camaro") || linea.equalsIgnoreCase("2016")) {
            precio = 45000000;
            setMarca("Chevrolet"); setLinea("Camaro"); setModelo("2016"); 
        }
        if (marca.equalsIgnoreCase("Kia") || modelo.equalsIgnoreCase("Sephia") || linea.equalsIgnoreCase("2012")) {
            precio = 16900000;
            setMarca("Kia"); setLinea("Sephia"); setModelo("2012"); 
        }
        if (marca.equalsIgnoreCase("Audi") || modelo.equalsIgnoreCase("A3") || linea.equalsIgnoreCase("2017")) {
            precio = 73900000;
            setMarca("Audi"); setLinea("A3"); setModelo("2017"); 
        }
        if (marca.equalsIgnoreCase("Nissan") || modelo.equalsIgnoreCase("Versa") || linea.equalsIgnoreCase("2015")) {
            precio = 35500000;
            setMarca("Nissan"); setLinea("Versa"); setModelo("2015");
        }
        return precio;
    }
    
}
